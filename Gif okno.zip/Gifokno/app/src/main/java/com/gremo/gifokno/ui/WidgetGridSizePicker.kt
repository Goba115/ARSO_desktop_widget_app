package com.gremo.gifokno.ui

// Odstranjeno na željo uporabnika, saj se velikost widgeta prilagaja neposredno na namizju Androida.
