package com.gremo.gifokno.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun AlarmClockWheelPicker(
    minutes: Int,
    seconds: Int,
    onValueChange: (newMinutes: Int, newSeconds: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    fun handleValueChange(m: Int, s: Int) {
        val totalSec = (m * 60) + s
        val clampedSec = totalSec.coerceAtLeast(30)
        onValueChange(clampedSec / 60, clampedSec % 60)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0D0E15), shape = RoundedCornerShape(20.dp))
            .padding(vertical = 20.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Interval osveževanja (min: 30s)",
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFF8E8E93),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Stolpec za Minute
            SingleWheelColumn(
                value = minutes,
                range = 0..120,
                onValueChange = { handleValueChange(it, seconds) },
                modifier = Modifier.weight(1f)
            )

            Text(
                text = ":",
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            // Stolpec za Sekunde
            SingleWheelColumn(
                value = seconds,
                range = 0..59,
                onValueChange = { handleValueChange(minutes, it) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Besedilo glede izbranega časa
        val formatText = when {
            minutes > 0 && seconds > 0 -> "Osveževanje vsakih $minutes min in $seconds sek"
            minutes > 0 -> "Osveževanje vsakih $minutes min"
            else -> "Osveževanje vsakih $seconds sek"
        }

        Text(
            text = formatText,
            color = Color(0xFF4CAF50),
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Hitre bližnjice za nastavitev časa
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            PresetChip(text = "30 sek") { handleValueChange(0, 30) }
            PresetChip(text = "1 min") { handleValueChange(1, 0) }
            PresetChip(text = "5 min") { handleValueChange(5, 0) }
            PresetChip(text = "6 min (ARSO)") { handleValueChange(6, 0) }
            PresetChip(text = "10 min") { handleValueChange(10, 0) }
        }
    }
}

@Composable
private fun PresetChip(
    text: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E202E),
        modifier = Modifier.padding(4.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun SingleWheelColumn(
    value: Int,
    range: IntRange,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val topValue = if (value > range.first) value - 1 else range.last
    val bottomValue = if (value < range.last) value + 1 else range.first

    var dragOffset by remember { mutableFloatStateOf(0f) }

    val draggableState = rememberDraggableState { delta ->
        dragOffset += delta
        if (dragOffset > 50f) {
            onValueChange(topValue)
            dragOffset = 0f
        } else if (dragOffset < -50f) {
            onValueChange(bottomValue)
            dragOffset = 0f
        }
    }

    Column(
        modifier = modifier
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStopped = { dragOffset = 0f }
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Zgornje nejasno število
        TextButton(
            onClick = { onValueChange(topValue) },
            modifier = Modifier.height(40.dp)
        ) {
            Text(
                text = String.format(Locale.getDefault(), "%02d", topValue),
                fontSize = 28.sp,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6C6E7E),
                modifier = Modifier.alpha(0.4f),
                textAlign = TextAlign.Center
            )
        }

        // Osrednje glavno veliko število
        Box(
            modifier = Modifier
                .height(60.dp)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = String.format(Locale.getDefault(), "%02d", value),
                fontSize = 54.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
        }

        // Spodnje nejasno število
        TextButton(
            onClick = { onValueChange(bottomValue) },
            modifier = Modifier.height(40.dp)
        ) {
            Text(
                text = String.format(Locale.getDefault(), "%02d", bottomValue),
                fontSize = 28.sp,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6C6E7E),
                modifier = Modifier.alpha(0.4f),
                textAlign = TextAlign.Center
            )
        }
    }
}