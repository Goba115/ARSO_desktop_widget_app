package com.gremo.gifokno

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import coil.decode.ImageDecoderDecoder
import coil.request.ImageRequest
import com.gremo.gifokno.data.GifRepository
import com.gremo.gifokno.ui.AlarmClockWheelPicker
import com.gremo.gifokno.ui.WidgetsDialog
import com.gremo.gifokno.ui.theme.GifOknoTheme
import com.gremo.gifokno.widget.GifWidgetProvider
import com.gremo.gifokno.worker.GifRefreshReceiver
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Zaženi načrtovano osveževanje
        GifRefreshReceiver.scheduleNextRefresh(this)

        setContent {
            GifOknoTheme {
                MainAppScreen()
            }
        }
    }
}

private fun isIgnoringBatteryOptimizations(context: Context): Boolean {
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    return powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: true
}

private fun requestIgnoreBatteryOptimizations(context: Context) {
    try {
        val intent = Intent().apply {
            action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
            data = Uri.parse("package:${context.packageName}")
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            val intent = Intent().apply {
                action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
            }
            context.startActivity(intent)
        } catch (e2: Exception) {
            val intent = Intent().apply {
                action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isBatteryUnrestricted by remember { mutableStateOf(isIgnoringBatteryOptimizations(context)) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isBatteryUnrestricted = isIgnoringBatteryOptimizations(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    var urlText by remember { mutableStateOf(GifRepository.getSavedUrl(context)) }
    var totalIntervalSeconds by remember { mutableIntStateOf(GifRepository.getIntervalSeconds(context)) }

    var minutes by remember(totalIntervalSeconds) { mutableIntStateOf(totalIntervalSeconds / 60) }
    var seconds by remember(totalIntervalSeconds) { mutableIntStateOf(totalIntervalSeconds % 60) }

    var isLoading by remember { mutableStateOf(false) }
    var isLastValid by remember { mutableStateOf(GifRepository.isLastValid(context)) }
    var lastStatus by remember { mutableStateOf(GifRepository.getLastStatus(context)) }
    var cachedFile by remember { mutableStateOf(GifRepository.getCachedFile(context)) }

    var showWidgetsDialog by remember { mutableStateOf(false) }

    fun refreshData() {
        scope.launch {
            isLoading = true
            val result = GifRepository.fetchAndValidateGif(context, urlText)
            isLoading = false

            isLastValid = GifRepository.isLastValid(context)
            lastStatus = GifRepository.getLastStatus(context)
            cachedFile = GifRepository.getCachedFile(context)

            // Osveži widgete na namizju
            GifWidgetProvider.updateAllWidgets(context)

            when (result) {
                is GifRepository.FetchResult.Success -> {
                    Toast.makeText(context, "Slika/GIF uspešno prenesena!", Toast.LENGTH_SHORT).show()
                }
                is GifRepository.FetchResult.Error -> {
                    Toast.makeText(context, "Osvežitev neuspešna", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (cachedFile == null) {
            refreshData()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Image,
                            contentDescription = null,
                            tint = Color(0xFF64B5F6),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Gif okno",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = { showWidgetsDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F51B5)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Widgets, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Widgeti", fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF14151F)
                )
            )
        },
        containerColor = Color(0xFF14151F)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Opozorilo za baterijo (če poraba NI neomejena)
            if (!isBatteryUnrestricted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF381418)),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF5252))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.BatteryAlert,
                                contentDescription = null,
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Poraba baterije je omejena!",
                                color = Color(0xFFFF5252),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Text(
                            text = "Aplikacija nima omogočene neomejene porabe baterije. Za zanesljivo in neprekinjeno osveževanje widgeta v ozadju prosimo omogočite neomejeno porabo.",
                            color = Color(0xFFFFCDD2),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Button(
                            onClick = {
                                requestIgnoreBatteryOptimizations(context)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Omogoči neomejeno porabo", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // 1. Nastavitev URL naslova
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E202E)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Spletni naslov GIF / slike (URL)",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = urlText,
                        onValueChange = { urlText = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("https://...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF64B5F6),
                            unfocusedBorderColor = Color(0xFF373A4D),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                urlText = GifRepository.DEFAULT_URL
                            }
                        ) {
                            Text("ARSO Vremenski Radar", color = Color(0xFF64B5F6), fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                GifRepository.saveUrl(context, urlText)
                                refreshData()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Shrani URL", fontSize = 13.sp)
                        }
                    }
                }
            }

            // 2. Izbirnik osveževanja (Alarm Clock Wheel Picker)
            AlarmClockWheelPicker(
                minutes = minutes,
                seconds = seconds,
                onValueChange = { newMin, newSec ->
                    minutes = newMin
                    seconds = newSec
                    val newTotal = (newMin * 60) + newSec
                    totalIntervalSeconds = newTotal
                    GifRepository.saveIntervalSeconds(context, newTotal)
                    GifRefreshReceiver.scheduleNextRefresh(context)
                }
            )

            // 3. Predogled GIF-a in status
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E202E)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Predogled in status",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )

                        Button(
                            onClick = { refreshData() },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F51B5)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Osveži zdaj", fontSize = 13.sp)
                            }
                        }
                    }

                    // Prikaz predogleda
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0D0E15)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = Color(0xFF64B5F6))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Nalagam sliko...", color = Color.Gray, fontSize = 12.sp)
                            }
                        } else if (cachedFile != null) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(cachedFile)
                                    .decoderFactory(
                                        if (Build.VERSION.SDK_INT >= 28) ImageDecoderDecoder.Factory()
                                        else coil.decode.GifDecoder.Factory()
                                    )
                                    .build(),
                                contentDescription = "Predogled GIF",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Text("Še ni prenesene slike", color = Color.Gray)
                        }
                    }

                    // Pravilo za besedilo pod GIF-om:
                    // Če osvežitev NI bila uspešna -> z rdečo napiše "Osvežitev neuspešna" ob zadnjem uspešnem GIF-u.
                    // Če JE osvežitev bila uspešna -> besedilo spodaj odstrani (View.GONE)
                    if (!isLastValid || lastStatus.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Osvežitev neuspešna",
                                color = Color(0xFFFF5252),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showWidgetsDialog) {
        WidgetsDialog(
            onDismissRequest = { showWidgetsDialog = false },
            onForceRefreshWidgets = {
                refreshData()
            }
        )
    }
}