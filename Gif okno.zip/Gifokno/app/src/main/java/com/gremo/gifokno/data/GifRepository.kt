package com.gremo.gifokno.data

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object GifRepository {

    private const val TAG = "GifRepository"
    private const val PREFS_NAME = "gif_okno_prefs"
    private const val KEY_URL = "gif_url"
    private const val KEY_INTERVAL_SECONDS = "interval_seconds"
    private const val KEY_LAST_STATUS = "last_status"
    private const val KEY_LAST_ERROR = "last_error"
    private const val KEY_IS_VALID = "is_valid"

    const val DEFAULT_URL = "https://meteo.arso.gov.si/uploads/probase/www/observ/radar/si0-rm-anim.gif"
    const val DEFAULT_INTERVAL_SECONDS = 360 // 6 minut (6:00)
    const val MIN_INTERVAL_SECONDS = 30 // Najmanj 30 sekund (preprečevanje preobremenitve strežnika)

    const val ERROR_SERVER_INVALID = "Odgovor strežnika ni pravilen"
    const val ERROR_REFRESH_FAILED = "Osvežitev neuspešna"

    sealed class FetchResult {
        object Success : FetchResult()
        data class Error(val message: String) : FetchResult()
    }

    fun getSavedUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_URL, DEFAULT_URL) ?: DEFAULT_URL
    }

    fun saveUrl(context: Context, url: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_URL, url.trim()).apply()
    }

    fun getIntervalSeconds(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_INTERVAL_SECONDS, DEFAULT_INTERVAL_SECONDS).coerceAtLeast(MIN_INTERVAL_SECONDS)
    }

    fun saveIntervalSeconds(context: Context, seconds: Int) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_INTERVAL_SECONDS, seconds.coerceAtLeast(MIN_INTERVAL_SECONDS)).apply()
    }

    fun getLastStatus(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LAST_STATUS, "") ?: ""
    }

    fun getLastError(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LAST_ERROR, null)
    }

    fun isLastValid(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_IS_VALID, true)
    }

    fun getCachedFile(context: Context): File? {
        val file = File(context.filesDir, "cached_widget_image.gif")
        return if (file.exists() && file.length() > 0) file else null
    }

    suspend fun fetchAndValidateGif(context: Context, customUrl: String? = null): FetchResult =
        withContext(Dispatchers.IO) {
            val targetUrlStr = customUrl ?: getSavedUrl(context)
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

            Log.d(TAG, "Prenos datoteke z URL: $targetUrlStr")

            try {
                val url = URL(targetUrlStr)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 12000
                connection.readTimeout = 12000
                connection.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Android Gifokno App"
                )
                connection.instanceFollowRedirects = true
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode !in 200..299) {
                    val errMsg = ERROR_REFRESH_FAILED
                    prefs.edit()
                        .putString(KEY_LAST_STATUS, ERROR_REFRESH_FAILED)
                        .putString(KEY_LAST_ERROR, errMsg)
                        .putBoolean(KEY_IS_VALID, false)
                        .apply()
                    return@withContext FetchResult.Error(errMsg)
                }

                val bytes = connection.inputStream.use { it.readBytes() }

                if (bytes.size < 10) {
                    val errMsg = ERROR_REFRESH_FAILED
                    prefs.edit()
                        .putString(KEY_LAST_STATUS, ERROR_REFRESH_FAILED)
                        .putString(KEY_LAST_ERROR, errMsg)
                        .putBoolean(KEY_IS_VALID, false)
                        .apply()
                    return@withContext FetchResult.Error(errMsg)
                }

                val isValidImage = isGifOrImage(bytes)

                if (!isValidImage) {
                    Log.w(TAG, "Prejeta datoteka ni veljavna slika ali GIF!")
                    val errMsg = ERROR_SERVER_INVALID
                    prefs.edit()
                        .putString(KEY_LAST_STATUS, ERROR_REFRESH_FAILED)
                        .putString(KEY_LAST_ERROR, errMsg)
                        .putBoolean(KEY_IS_VALID, false)
                        .apply()
                    return@withContext FetchResult.Error(errMsg)
                }

                // Uspešno prenesena slika -> shrani v lokalno datoteko
                val outputFile = File(context.filesDir, "cached_widget_image.gif")
                FileOutputStream(outputFile).use { fos ->
                    fos.write(bytes)
                }

                // Ob uspešnem osveževanju se besedilo pod GIF-om odstrani ("")
                prefs.edit()
                    .putString(KEY_LAST_STATUS, "")
                    .putString(KEY_LAST_ERROR, null)
                    .putBoolean(KEY_IS_VALID, true)
                    .apply()

                Log.i(TAG, "Slika/GIF uspešno prenesena in shranjena (${bytes.size} B)")
                FetchResult.Success
            } catch (e: Exception) {
                Log.e(TAG, "Napaka pri prenosu GIF-a: ${e.message}", e)
                val errMsg = ERROR_REFRESH_FAILED
                prefs.edit()
                    .putString(KEY_LAST_STATUS, ERROR_REFRESH_FAILED)
                    .putString(KEY_LAST_ERROR, errMsg)
                    .putBoolean(KEY_IS_VALID, false)
                    .apply()
                FetchResult.Error(errMsg)
            }
        }

    private fun isGifOrImage(bytes: ByteArray): Boolean {
        // GIF magic bytes: "GIF87a" ali "GIF89a" -> 0x47, 0x49, 0x46, 0x38
        if (bytes.size >= 4 &&
            bytes[0] == 0x47.toByte() &&
            bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte() &&
            bytes[3] == 0x38.toByte()
        ) {
            return true
        }

        // PNG: 0x89 0x50 0x4E 0x47
        if (bytes.size >= 4 &&
            bytes[0] == 0x89.toByte() &&
            bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() &&
            bytes[3] == 0x47.toByte()
        ) {
            return true
        }

        // JPEG: 0xFF 0xD8 0xFF
        if (bytes.size >= 3 &&
            bytes[0] == 0xFF.toByte() &&
            bytes[1] == 0xD8.toByte() &&
            bytes[2] == 0xFF.toByte()
        ) {
            return true
        }

        // WEBP: 0x52 0x49 0x46 0x46 (RIFF)
        if (bytes.size >= 12 &&
            bytes[0] == 0x52.toByte() &&
            bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte() &&
            bytes[3] == 0x46.toByte() &&
            bytes[8] == 0x57.toByte() &&
            bytes[9] == 0x45.toByte() &&
            bytes[10] == 0x42.toByte() &&
            bytes[11] == 0x50.toByte()
        ) {
            return true
        }

        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            options.outWidth > 0 && options.outHeight > 0
        } catch (e: Exception) {
            false
        }
    }
}