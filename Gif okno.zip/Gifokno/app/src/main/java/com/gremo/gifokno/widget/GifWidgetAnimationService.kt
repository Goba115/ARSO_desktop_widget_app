package com.gremo.gifokno.widget

import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Movie
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import com.gremo.gifokno.R
import com.gremo.gifokno.data.GifRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GifWidgetAnimationService : Service() {

    companion object {
        private const val TAG = "GifWidgetAnimService"

        fun startAnimationService(context: Context) {
            try {
                val intent = Intent(context, GifWidgetAnimationService::class.java)
                context.startService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Ne morem zagnati storitve animacije: ${e.message}")
            }
        }

        fun stopAnimationService(context: Context) {
            try {
                val intent = Intent(context, GifWidgetAnimationService::class.java)
                context.stopService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Ne morem ustaviti storitve animacije: ${e.message}")
            }
        }
    }

    private var animationJob: Job? = null
    private var frames: List<Bitmap> = emptyList()
    private var isScreenOn = true

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    Log.d(TAG, "Zaslon izklopljen - pavza animacije")
                    isScreenOn = false
                }
                Intent.ACTION_SCREEN_ON -> {
                    Log.d(TAG, "Zaslon vklopljen - nadaljujem animacijo")
                    isScreenOn = true
                    startOrResumeAnimationLoop()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Ustvarjanje GifWidgetAnimationService")

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        isScreenOn = powerManager?.isInteractive ?: true

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand GifWidgetAnimationService")
        loadFramesAndStartAnimation()
        return START_STICKY
    }

    private fun loadFramesAndStartAnimation() {
        val file = GifRepository.getCachedFile(this)
        if (file == null) {
            Log.w(TAG, "Ni datoteke GIF za animacijo")
            stopSelf()
            return
        }

        try {
            val movie = Movie.decodeFile(file.absolutePath)
            if (movie == null || movie.duration() <= 0) {
                Log.d(TAG, "Datoteka ni animiran GIF ali ima trajanje 0")
                stopSelf()
                return
            }

            val width = movie.width().coerceAtLeast(1)
            val height = movie.height().coerceAtLeast(1)
            val duration = movie.duration()

            val frameCount = (duration / 200).coerceIn(4, 20)
            val step = duration / frameCount

            val newFrames = mutableListOf<Bitmap>()
            for (i in 0 until frameCount) {
                val timeMs = i * step
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                movie.setTime(timeMs)
                movie.draw(canvas, 0f, 0f)
                newFrames.add(bitmap)
            }

            frames = newFrames
            Log.d(TAG, "Pripravljenih ${frames.size} okvirjev za neskončno predvajanje")

            startOrResumeAnimationLoop()
        } catch (e: Exception) {
            Log.e(TAG, "Napaka pri branju GIF okvirjev: ${e.message}", e)
        }
    }

    private fun startOrResumeAnimationLoop() {
        animationJob?.cancel()

        if (frames.isEmpty()) return

        animationJob = CoroutineScope(Dispatchers.Main).launch {
            var currentFrameIndex = 0
            val appWidgetManager = AppWidgetManager.getInstance(applicationContext)
            val componentName = ComponentName(applicationContext, GifWidgetProvider::class.java)

            while (isActive && frames.isNotEmpty()) {
                if (!isScreenOn) {
                    delay(1000)
                    continue
                }

                val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
                if (appWidgetIds.isEmpty()) {
                    Log.d(TAG, "Ni aktivnih widgetov, ustavljam animacijo")
                    stopSelf()
                    break
                }

                val bitmap = frames[currentFrameIndex]
                currentFrameIndex = (currentFrameIndex + 1) % frames.size

                val views = RemoteViews(packageName, R.layout.widget_layout)
                views.setImageViewBitmap(R.id.widget_image_view, bitmap)
                views.setViewVisibility(R.id.widget_error_text, View.GONE)

                val isValid = GifRepository.isLastValid(applicationContext)
                val lastStatus = GifRepository.getLastStatus(applicationContext)

                if (!isValid || lastStatus.isNotEmpty()) {
                    views.setViewVisibility(R.id.widget_bottom_bar, View.VISIBLE)
                    views.setTextViewText(R.id.widget_status_text, "Osvežitev neuspešna")
                    views.setTextColor(R.id.widget_status_text, 0xFFFF5252.toInt())
                } else {
                    views.setViewVisibility(R.id.widget_bottom_bar, View.GONE)
                }

                appWidgetManager.updateAppWidget(appWidgetIds, views)

                delay(250) // 4 FPS za neskončno predvajanje
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Uničevanje GifWidgetAnimationService")
        animationJob?.cancel()
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
            // Ignoriraj
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}