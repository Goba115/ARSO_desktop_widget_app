package com.gremo.gifokno.worker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import com.gremo.gifokno.data.GifRepository
import com.gremo.gifokno.widget.GifWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GifRefreshReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_SCHEDULED_REFRESH = "com.gremo.gifokno.ACTION_SCHEDULED_REFRESH"
        private const val TAG = "GifRefreshReceiver"

        fun scheduleNextRefresh(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intervalSeconds = GifRepository.getIntervalSeconds(context)
            val triggerMillis = SystemClock.elapsedRealtime() + (intervalSeconds * 1000L)

            val intent = Intent(context, GifRefreshReceiver::class.java).apply {
                action = ACTION_SCHEDULED_REFRESH
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                1001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
                Log.d(TAG, "Naslednje osveževanje nastavljeno čez $intervalSeconds sekund.")
            } catch (e: Exception) {
                Log.e(TAG, "Napaka pri nastavljanju alarma: ${e.message}")
            }
        }

        fun cancelScheduledRefresh(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, GifRefreshReceiver::class.java).apply {
                action = ACTION_SCHEDULED_REFRESH
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                1001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Sprejeto dejanje: ${intent.action}")

        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == ACTION_SCHEDULED_REFRESH) {
            // Izvedi osveževanje v ozadju
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val result = GifRepository.fetchAndValidateGif(context)
                    Log.d(TAG, "Rezultat osveževanja: $result")

                    // Osveži vse widgete
                    GifWidgetProvider.updateAllWidgets(context)
                } finally {
                    scheduleNextRefresh(context)
                    pendingResult.finish()
                }
            }
        }
    }
}