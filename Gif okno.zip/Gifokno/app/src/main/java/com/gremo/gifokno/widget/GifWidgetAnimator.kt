package com.gremo.gifokno.widget

// Zamenjano z GifWidgetAnimationService za samostojno delovanje v ozadju
