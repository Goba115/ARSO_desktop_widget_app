package com.gremo.gifokno.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import com.gremo.gifokno.MainActivity
import com.gremo.gifokno.R
import com.gremo.gifokno.data.GifRepository
import com.gremo.gifokno.worker.GifRefreshReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GifWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH_WIDGET = "com.gremo.gifokno.ACTION_REFRESH_WIDGET"
        private const val TAG = "GifWidgetProvider"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, GifWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)

            for (appWidgetId in appWidgetIds) {
                updateSingleWidget(context, appWidgetManager, appWidgetId)
            }

            // Zaženi/osveži samostojno ozadno storitev za neskončno animacijo GIF-a
            GifWidgetAnimationService.startAnimationService(context)
        }

        fun updateSingleWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_layout)
            val isValid = GifRepository.isLastValid(context)
            val lastStatus = GifRepository.getLastStatus(context)
            val cachedFile = GifRepository.getCachedFile(context)

            // Intent za klik na gumb Osveži
            val refreshIntent = Intent(context, GifWidgetProvider::class.java).apply {
                action = ACTION_REFRESH_WIDGET
            }
            val refreshPendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh_button, refreshPendingIntent)

            // Intent za klik na sliko -> odpri aplikacijo
            val openAppIntent = Intent(context, MainActivity::class.java)
            val openAppPendingIntent = PendingIntent.getActivity(
                context,
                0,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_image_view, openAppPendingIntent)

            // Prikaz zadnjega uspešnega GIF-a
            if (cachedFile != null) {
                try {
                    val bitmap = BitmapFactory.decodeFile(cachedFile.absolutePath)
                    if (bitmap != null) {
                        views.setImageViewBitmap(R.id.widget_image_view, bitmap)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Napaka pri branju slike: ${e.message}")
                }
            }

            views.setViewVisibility(R.id.widget_error_text, View.GONE)

            // Pravilo za besedilo spodaj:
            // Če je osvežitev neuspešna -> rdeče besedilo "Osvežitev neuspešna" ob zadnjem veljavnem GIF-u
            // Če je bila osvežitev uspešna -> besedilo spodaj odstrani (View.GONE)
            if (!isValid || lastStatus.isNotEmpty()) {
                views.setViewVisibility(R.id.widget_bottom_bar, View.VISIBLE)
                views.setTextViewText(
                    R.id.widget_status_text,
                    "Osvežitev neuspešna"
                )
                views.setTextColor(R.id.widget_status_text, 0xFFFF5252.toInt())
            } else {
                views.setViewVisibility(R.id.widget_bottom_bar, View.GONE)
            }

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)
        for (appWidgetId in appWidgetIds) {
            updateSingleWidget(context, appWidgetManager, appWidgetId)
        }

        // Poskrbi da je načrtovano osveževanje aktivno
        GifRefreshReceiver.scheduleNextRefresh(context)

        // Zaženi animacijo
        GifWidgetAnimationService.startAnimationService(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        Log.d(TAG, "Sprejet intent v WidgetProvider: ${intent.action}")

        if (intent.action == ACTION_REFRESH_WIDGET) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    GifRepository.fetchAndValidateGif(context)
                    updateAllWidgets(context)
                } finally {
                    GifRefreshReceiver.scheduleNextRefresh(context)
                    pendingResult.finish()
                }
            }
        }
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        GifWidgetAnimationService.stopAnimationService(context)
    }
}