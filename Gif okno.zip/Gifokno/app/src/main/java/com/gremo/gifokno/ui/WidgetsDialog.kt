package com.gremo.gifokno.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.decode.ImageDecoderDecoder
import coil.request.ImageRequest
import com.gremo.gifokno.data.GifRepository
import com.gremo.gifokno.widget.GifWidgetProvider

@Composable
fun WidgetsDialog(
    onDismissRequest: () -> Unit,
    onForceRefreshWidgets: () -> Unit
) {
    val context = LocalContext.current
    val appWidgetManager = remember { AppWidgetManager.getInstance(context) }
    val componentName = remember { ComponentName(context, GifWidgetProvider::class.java) }
    val activeWidgetIds = remember { appWidgetManager.getAppWidgetIds(componentName) }
    val activeCount = activeWidgetIds.size

    val cachedFile = remember { GifRepository.getCachedFile(context) }
    val isLastValid = remember { GifRepository.isLastValid(context) }
    val lastStatus = remember { GifRepository.getLastStatus(context) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = {
            Button(
                onClick = onDismissRequest,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F51B5))
            ) {
                Text("Zapri", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    onForceRefreshWidgets()
                }
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Osveži widgete")
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Widgets,
                    contentDescription = null,
                    tint = Color(0xFF64B5F6),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Widgeti na namizju", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Status aktivnih widgetov
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (activeCount > 0) Color(0xFF1B382B) else Color(0xFF2C2213)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (activeCount > 0) Icons.Default.CheckCircle else Icons.Default.Widgets,
                            contentDescription = null,
                            tint = if (activeCount > 0) Color(0xFF81C784) else Color(0xFFFFB74D),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (activeCount > 0)
                                    "Aktivnih widgetov na namizju: $activeCount"
                                else
                                    "Na namizju še nimate dodanega widgeta",
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (activeCount > 0)
                                    "Widget samodejno predvaja vaš GIF/sliko."
                                else
                                    "Dodajte widget na namizje za hiter vpogled.",
                                color = Color(0xFFB0BEC5),
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Predogled widgeta
                Text(
                    text = "Predogled widgeta:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFB0BEC5)
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF12131C))
                        .padding(8.dp)
                ) {
                    if (cachedFile != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(cachedFile)
                                .decoderFactory(
                                    if (Build.VERSION.SDK_INT >= 28) ImageDecoderDecoder.Factory()
                                    else coil.decode.GifDecoder.Factory()
                                )
                                .build(),
                            contentDescription = "Predogled GIF widgeta",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth().height(130.dp)
                        )
                    } else {
                        Text(
                            text = "Nalagam predogled...",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    // Pravilo: Če osvežitev NI bila uspešna -> rdeče besedilo "Osvežitev neuspešna" ob zadnjem veljavnem GIF-u.
                    // Če je osvežitev bila uspešna -> besedilo spodaj odstrani!
                    if (!isLastValid || lastStatus.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomStart)
                                .background(Color(0xCC000000))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Osvežitev neuspešna",
                                color = Color(0xFFFF5252),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Gumb za dodajanje na namizje (Pin AppWidget)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && appWidgetManager.isRequestPinAppWidgetSupported) {
                    Button(
                        onClick = {
                            appWidgetManager.requestPinAppWidget(componentName, null, null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Dodaj widget na namizje", fontWeight = FontWeight.Bold)
                    }
                }

                // Navodila za ročno dodajanje in spreminjanje velikosti
                Text(
                    text = "Navodila: Pridržite prst na namizju -> izberite 'Widgeti' -> dodajte 'Gif okno'. Velikost widgeta na namizju lahko nato poljubno spremenite z vlečenjem robov.",
                    fontSize = 11.sp,
                    color = Color(0xFF90A4AE),
                    lineHeight = 15.sp
                )
            }
        },
        containerColor = Color(0xFF1E1F2B),
        titleContentColor = Color.White,
        textContentColor = Color.White
    )
}